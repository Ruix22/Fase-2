# Simulador Kernel / Sistema de Archivos - Programacion Estructurada

Proyecto de la Tarea Practica 1 (Fase 2) - Implementacion en lenguaje C de
modulos de gestion de procesos (contexto kernel) y de bloques de archivo
(contexto sistemas de archivos), con optimizacion de busqueda mediante
tabla hash y verificacion de memoria dinamica.

## Integrante
- Steven Ruiz (Grupo 5)

## Estructura del proyecto
```
include/     Archivos de cabecera (.h) - interfaz publica de cada modulo
src/         Implementacion (.c) de cada modulo
  main.c         Menu interactivo que integra todos los modulos
  kernel.c       Gestion de procesos: PCB, lista enlazada, Round Robin
  filesystem.c   Gestion de bloques de archivo: lista enlazada + tabla hash
  benchmark.c    Medicion comparativa: busqueda lineal vs. busqueda hash
  memtrace.c     Contabilidad de malloc/free (deteccion de fugas)
Makefile     Automatiza la compilacion
```

## Compilacion
```bash
make            # compila con gcc -std=c11 -Wall -Wextra -Wpedantic
./bin/simulador # ejecuta el menu interactivo
make clean      # elimina el binario
```

## Pruebas realizadas
Se ejecutaron escenarios automatizados redirigiendo la entrada estandar
(ver carpeta tests/ del entregable de informe), cubriendo: creacion y
planificacion de procesos, creacion/lectura/eliminacion de archivos,
casos limite (rafaga invalida, PID inexistente, archivo duplicado) y
el benchmark de rendimiento (opcion 9 del menu).

## Optimizacion aplicada
El modulo de sistema de archivos incorpora una tabla hash (funcion
djb2) para indexar los archivos por nombre, reduciendo la busqueda de
O(n) (lineal) a O(1) en promedio. El modulo benchmark.c mide y compara
ambos metodos para N = 100, 1000, 5000 y 10000 archivos.

## Verificacion de memoria
El modulo memtrace.c contabiliza cada malloc/free realizado. Al
finalizar el programa se imprime un reporte que confirma que el
numero de reservas es igual al de liberaciones (sin fugas).
