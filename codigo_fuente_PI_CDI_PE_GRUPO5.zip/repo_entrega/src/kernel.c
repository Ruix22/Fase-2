/*
 * kernel.c - implementacion del modulo de gestion de procesos.
 */
#include <stdio.h>
#include <string.h>
#include "kernel.h"
#include "memtrace.h"

static const char *nombre_estado(EstadoProceso e)
{
    switch (e) {
        case ESTADO_LISTO:      return "LISTO";
        case ESTADO_EJECUTANDO: return "EJECUTANDO";
        case ESTADO_TERMINADO:  return "TERMINADO";
        default:                return "DESCONOCIDO";
    }
}

void cola_inicializar(ColaProcesos *cola)
{
    cola->frente = NULL;
    cola->final = NULL;
    cola->cantidad = 0;
    cola->siguiente_pid = 1; /* los pid inician en 1 */
}

Proceso *proceso_crear(ColaProcesos *cola, const char *nombre,
                        int prioridad, int rafaga)
{
    /* Validacion de parametros: programacion defensiva. */
    if (cola == NULL || nombre == NULL || nombre[0] == '\0' || rafaga <= 0) {
        return NULL;
    }

    Proceso *p = (Proceso *) MT_MALLOC(sizeof(Proceso));
    if (p == NULL) {
        return NULL; /* mt_malloc ya reporta el error */
    }

    p->pid = cola->siguiente_pid++;
    /* strncpy + terminador explicito: evita desbordamiento de buffer. */
    strncpy(p->nombre, nombre, MAX_NOMBRE_PROCESO - 1);
    p->nombre[MAX_NOMBRE_PROCESO - 1] = '\0';
    p->prioridad = prioridad;
    p->rafaga_total = rafaga;
    p->rafaga_restante = rafaga;
    p->estado = ESTADO_LISTO;
    p->siguiente = NULL;

    /* Insercion al final de la lista enlazada (cola FIFO). */
    if (cola->final == NULL) {
        cola->frente = p;
        cola->final = p;
    } else {
        cola->final->siguiente = p;
        cola->final = p;
    }
    cola->cantidad++;
    return p;
}

int proceso_eliminar(ColaProcesos *cola, int pid)
{
    if (cola == NULL || cola->frente == NULL) {
        return 0;
    }

    Proceso *actual = cola->frente;
    Proceso *anterior = NULL;

    while (actual != NULL && actual->pid != pid) {
        anterior = actual;
        actual = actual->siguiente;
    }

    if (actual == NULL) {
        return 0; /* no existe un proceso con ese pid */
    }

    if (anterior == NULL) {
        cola->frente = actual->siguiente; /* eliminar el primero */
    } else {
        anterior->siguiente = actual->siguiente;
    }
    if (actual == cola->final) {
        cola->final = anterior;
    }

    MT_FREE(actual);
    cola->cantidad--;
    return 1;
}

void cola_listar(const ColaProcesos *cola)
{
    if (cola == NULL || cola->frente == NULL) {
        printf("  (no hay procesos en la cola)\n");
        return;
    }
    printf("  %-4s %-20s %-6s %-8s %-10s %-12s\n",
           "PID", "NOMBRE", "PRIOR", "RAFAGA", "RESTANTE", "ESTADO");
    for (Proceso *p = cola->frente; p != NULL; p = p->siguiente) {
        printf("  %-4d %-20s %-6d %-8d %-10d %-12s\n",
               p->pid, p->nombre, p->prioridad, p->rafaga_total,
               p->rafaga_restante, nombre_estado(p->estado));
    }
}

void planificador_round_robin(ColaProcesos *cola, int quantum)
{
    if (cola == NULL || cola->frente == NULL || quantum <= 0) {
        printf("  (no hay procesos que planificar o quantum invalido)\n");
        return;
    }

    printf("\n  Traza de ejecucion (quantum = %d):\n", quantum);
    int tiempo = 0;
    int pendientes = cola->cantidad;

    /* Simulacion Round Robin: se recorre la lista de forma circular
     * usando los mismos nodos (no se reordena memoria), avanzando
     * el 'restante' de cada proceso hasta que todos terminan. */
    while (pendientes > 0) {
        for (Proceso *p = cola->frente; p != NULL; p = p->siguiente) {
            if (p->estado == ESTADO_TERMINADO) {
                continue;
            }
            p->estado = ESTADO_EJECUTANDO;
            int ejecutado = (p->rafaga_restante < quantum) ? p->rafaga_restante : quantum;
            printf("    t=%-3d  PID %-3d (%-12s) ejecuta %d unidad(es) -> restante %d\n",
                   tiempo, p->pid, p->nombre, ejecutado, p->rafaga_restante - ejecutado);
            p->rafaga_restante -= ejecutado;
            tiempo += ejecutado;

            if (p->rafaga_restante <= 0) {
                p->estado = ESTADO_TERMINADO;
                pendientes--;
                printf("           >> PID %d finalizo en t=%d\n", p->pid, tiempo);
            } else {
                p->estado = ESTADO_LISTO;
            }
        }
    }
    printf("  Planificacion completa. Tiempo total simulado: %d unidades.\n", tiempo);
}

void cola_liberar(ColaProcesos *cola)
{
    if (cola == NULL) {
        return;
    }
    Proceso *actual = cola->frente;
    while (actual != NULL) {
        Proceso *siguiente = actual->siguiente;
        MT_FREE(actual);
        actual = siguiente;
    }
    cola->frente = NULL;
    cola->final = NULL;
    cola->cantidad = 0;
}
