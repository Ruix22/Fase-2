/*
 * main.c
 * ---------------------------------------------------------------
 * Programa principal: menu interactivo que integra el modulo de
 * gestion de procesos (kernel.c, contexto "kernel") y el modulo de
 * gestion de bloques de archivo (filesystem.c, contexto "sistemas
 * de archivos"), ademas del benchmark de rendimiento.
 *
 * Materia: Programacion Estructurada - Tarea practica 1, fase 2.
 * ---------------------------------------------------------------
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "kernel.h"
#include "filesystem.h"
#include "benchmark.h"
#include "memtrace.h"

/* Lee una linea de la entrada estandar de forma segura (evita
 * desbordamientos de buffer) y elimina el salto de linea final. */
static void leer_linea(char *buffer, int tam)
{
    if (fgets(buffer, tam, stdin) != NULL) {
        size_t len = strlen(buffer);
        if (len > 0 && buffer[len - 1] == '\n') {
            buffer[len - 1] = '\0';
        }
    } else {
        buffer[0] = '\0';
    }
}

/* Lee un entero de forma segura; retorna 1 si la conversion fue
 * valida, 0 en caso contrario (entrada no numerica). */
static int leer_entero(const char *prompt, int *valor)
{
    char linea[64];
    printf("%s", prompt);
    leer_linea(linea, sizeof(linea));
    return sscanf(linea, "%d", valor) == 1;
}

static void menu_mostrar(void)
{
    printf("\n============ SIMULADOR KERNEL / SISTEMA DE ARCHIVOS ============\n");
    printf(" -- Gestion de procesos (kernel) --\n");
    printf("  1. Crear proceso\n");
    printf("  2. Listar procesos\n");
    printf("  3. Eliminar proceso\n");
    printf("  4. Ejecutar planificador Round Robin\n");
    printf(" -- Gestion de archivos (bloques) --\n");
    printf("  5. Crear archivo\n");
    printf("  6. Listar archivos\n");
    printf("  7. Leer archivo\n");
    printf("  8. Eliminar archivo\n");
    printf(" -- Pruebas y rendimiento --\n");
    printf("  9. Ejecutar benchmark de rendimiento (lineal vs. hash)\n");
    printf("  0. Salir\n");
    printf("==================================================================\n");
}

int main(void)
{
    ColaProcesos cola;
    SistemaArchivos fs;
    cola_inicializar(&cola);
    fs_inicializar(&fs);

    int opcion;
    char nombre[128];
    char contenido[512];

    do {
        menu_mostrar();
        if (!leer_entero("Seleccione una opcion: ", &opcion)) {
            printf("  Entrada invalida. Ingrese un numero.\n");
            continue;
        }

        switch (opcion) {
            case 1: {
                int prioridad, rafaga;
                printf("  Nombre del proceso: ");
                leer_linea(nombre, sizeof(nombre));
                if (!leer_entero("  Prioridad (1-5): ", &prioridad)) { printf("  Valor invalido.\n"); break; }
                if (!leer_entero("  Rafaga de CPU (unidades > 0): ", &rafaga)) { printf("  Valor invalido.\n"); break; }
                Proceso *p = proceso_crear(&cola, nombre, prioridad, rafaga);
                if (p != NULL) {
                    printf("  Proceso creado con PID %d.\n", p->pid);
                } else {
                    printf("  Error: no se pudo crear el proceso (datos invalidos o memoria).\n");
                }
                break;
            }
            case 2:
                cola_listar(&cola);
                break;
            case 3: {
                int pid;
                if (!leer_entero("  PID a eliminar: ", &pid)) { printf("  Valor invalido.\n"); break; }
                printf(proceso_eliminar(&cola, pid) ? "  Proceso eliminado.\n" : "  No existe un proceso con ese PID.\n");
                break;
            }
            case 4: {
                if (cola.frente == NULL) {
                    /* Validar ANTES de pedir el quantum: evita solicitar
                     * un dato que de todas formas seria descartado. */
                    printf("  No hay procesos en la cola para planificar.\n");
                    break;
                }
                int quantum;
                if (!leer_entero("  Quantum (unidades > 0): ", &quantum)) { printf("  Valor invalido.\n"); break; }
                planificador_round_robin(&cola, quantum);
                break;
            }
            case 5:
                printf("  Nombre del archivo: ");
                leer_linea(nombre, sizeof(nombre));
                printf("  Contenido: ");
                leer_linea(contenido, sizeof(contenido));
                if (fs_crear_archivo(&fs, nombre, contenido) != NULL) {
                    printf("  Archivo creado correctamente.\n");
                } else {
                    printf("  Error: el archivo ya existe o los datos son invalidos.\n");
                }
                break;
            case 6:
                fs_listar_archivos(&fs);
                break;
            case 7:
                printf("  Nombre del archivo a leer: ");
                leer_linea(nombre, sizeof(nombre));
                fs_leer_archivo(&fs, nombre);
                break;
            case 8:
                printf("  Nombre del archivo a eliminar: ");
                leer_linea(nombre, sizeof(nombre));
                printf(fs_eliminar_archivo(&fs, nombre) ? "  Archivo eliminado.\n" : "  No existe un archivo con ese nombre.\n");
                break;
            case 9:
                ejecutar_benchmark();
                break;
            case 0:
                printf("  Finalizando programa...\n");
                break;
            default:
                printf("  Opcion no valida.\n");
        }
    } while (opcion != 0);

    /* Liberacion ordenada de toda la memoria dinamica antes de
     * finalizar, para evitar fugas. */
    cola_liberar(&cola);
    fs_liberar(&fs);
    mt_reporte();

    return 0;
}
