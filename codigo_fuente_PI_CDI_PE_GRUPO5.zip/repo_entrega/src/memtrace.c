/*
 * memtrace.c - implementacion del rastreador de memoria dinamica.
 */
#include <stdio.h>
#include <stdlib.h>
#include "memtrace.h"

static long g_reservas = 0;      /* veces que se llamo a malloc */
static long g_liberaciones = 0;  /* veces que se llamo a free (ptr != NULL) */
static long g_bytes_actuales = 0;
static long g_bytes_pico = 0;

void *mt_malloc(size_t tam, const char *origen)
{
    void *p = malloc(tam);
    if (p == NULL) {
        /* Buena practica: nunca asumir que malloc siempre tiene exito. */
        fprintf(stderr, "[memtrace] ERROR: malloc(%zu) fallo en %s\n", tam, origen);
        return NULL;
    }
    g_reservas++;
    g_bytes_actuales += (long)tam;
    if (g_bytes_actuales > g_bytes_pico) {
        g_bytes_pico = g_bytes_actuales;
    }
    return p;
}

void mt_free(void *ptr)
{
    if (ptr == NULL) {
        return; /* liberar NULL es valido en C, pero no lo contamos */
    }
    free(ptr);
    g_liberaciones++;
}

int mt_reporte(void)
{
    printf("\n----- Reporte de memoria dinamica (memtrace) -----\n");
    printf("  Reservas  (malloc) : %ld\n", g_reservas);
    printf("  Liberaciones (free): %ld\n", g_liberaciones);
    printf("  Pico de uso        : %ld bytes\n", g_bytes_pico);

    if (g_reservas == g_liberaciones) {
        printf("  Resultado           : OK - sin fugas de memoria detectadas.\n");
        printf("----------------------------------------------------\n");
        return 1;
    }
    printf("  Resultado           : FUGA DETECTADA (%ld bloques sin liberar)\n",
           g_reservas - g_liberaciones);
    printf("----------------------------------------------------\n");
    return 0;
}
