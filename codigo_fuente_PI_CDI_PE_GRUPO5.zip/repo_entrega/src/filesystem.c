/*
 * filesystem.c - implementacion del modulo de gestion de bloques
 * de archivo.
 */
#include <stdio.h>
#include <string.h>
#include "filesystem.h"
#include "memtrace.h"

void fs_inicializar(SistemaArchivos *fs)
{
    for (int i = 0; i < HASH_TAM; i++) {
        fs->tabla[i] = NULL;
    }
    fs->total_archivos = 0;
    fs->total_bloques_reservados = 0;
    fs->comparaciones_ultima_busqueda = 0;
}

unsigned int fs_hash(const char *nombre)
{
    /* Funcion hash tipo djb2 (Bernstein): rapida y con buena
     * dispersion para cadenas cortas como nombres de archivo. */
    unsigned long h = 5381;
    int c;
    while ((c = (unsigned char) *nombre++) != '\0') {
        h = ((h << 5) + h) + (unsigned long) c; /* h * 33 + c */
    }
    return (unsigned int) (h % HASH_TAM);
}

Archivo *fs_crear_archivo(SistemaArchivos *fs, const char *nombre,
                           const char *contenido)
{
    if (fs == NULL || nombre == NULL || nombre[0] == '\0') {
        return NULL;
    }
    if (fs_buscar_archivo(fs, nombre) != NULL) {
        return NULL; /* ya existe un archivo con ese nombre */
    }

    Archivo *arch = (Archivo *) MT_MALLOC(sizeof(Archivo));
    if (arch == NULL) {
        return NULL;
    }
    strncpy(arch->nombre, nombre, TAM_NOMBRE_ARCH - 1);
    arch->nombre[TAM_NOMBRE_ARCH - 1] = '\0';

    size_t tam = contenido != NULL ? strlen(contenido) : 0;
    arch->tam_bytes = (int) tam;
    arch->num_bloques = 0;
    arch->primer_bloque = NULL;
    arch->siguiente_hash = NULL;

    /* Division hacia arriba: numero de bloques necesarios. */
    int bloques_necesarios = (int) ((tam + TAM_BLOQUE - 1) / TAM_BLOQUE);
    if (bloques_necesarios == 0) {
        bloques_necesarios = 1; /* todo archivo ocupa al menos un bloque */
    }

    BloqueArchivo *anterior = NULL;
    size_t offset = 0;
    for (int i = 0; i < bloques_necesarios; i++) {
        BloqueArchivo *b = (BloqueArchivo *) MT_MALLOC(sizeof(BloqueArchivo));
        if (b == NULL) {
            /* Reserva parcial fallida: liberar lo ya reservado para
             * este archivo (evita fugas) y abortar la creacion. */
            BloqueArchivo *actual = arch->primer_bloque;
            while (actual != NULL) {
                BloqueArchivo *sig = actual->siguiente;
                MT_FREE(actual);
                actual = sig;
            }
            MT_FREE(arch);
            return NULL;
        }
        b->id_bloque = fs->total_bloques_reservados++;
        memset(b->datos, 0, TAM_BLOQUE);
        if (contenido != NULL) {
            size_t restante = tam - offset;
            size_t copiar = restante < TAM_BLOQUE ? restante : TAM_BLOQUE;
            memcpy(b->datos, contenido + offset, copiar);
            offset += copiar;
        }
        b->siguiente = NULL;

        if (anterior == NULL) {
            arch->primer_bloque = b;
        } else {
            anterior->siguiente = b;
        }
        anterior = b;
        arch->num_bloques++;
    }

    /* Insercion al frente de la lista de la cubeta hash: O(1). */
    unsigned int idx = fs_hash(arch->nombre);
    arch->siguiente_hash = fs->tabla[idx];
    fs->tabla[idx] = arch;
    fs->total_archivos++;

    return arch;
}

Archivo *fs_buscar_archivo(SistemaArchivos *fs, const char *nombre)
{
    if (fs == NULL || nombre == NULL) {
        return NULL;
    }
    unsigned int idx = fs_hash(nombre);
    long comparaciones = 0;
    for (Archivo *a = fs->tabla[idx]; a != NULL; a = a->siguiente_hash) {
        comparaciones++;
        if (strcmp(a->nombre, nombre) == 0) {
            fs->comparaciones_ultima_busqueda = comparaciones;
            return a;
        }
    }
    fs->comparaciones_ultima_busqueda = comparaciones;
    return NULL;
}

Archivo *fs_buscar_archivo_lineal(SistemaArchivos *fs, const char *nombre)
{
    /* Recorre TODAS las cubetas de la tabla, como si fuera una
     * unica lista enlazada sin indexar: representa el
     * comportamiento "antes de optimizar". */
    if (fs == NULL || nombre == NULL) {
        return NULL;
    }
    long comparaciones = 0;
    for (int i = 0; i < HASH_TAM; i++) {
        for (Archivo *a = fs->tabla[i]; a != NULL; a = a->siguiente_hash) {
            comparaciones++;
            if (strcmp(a->nombre, nombre) == 0) {
                fs->comparaciones_ultima_busqueda = comparaciones;
                return a;
            }
        }
    }
    fs->comparaciones_ultima_busqueda = comparaciones;
    return NULL;
}

int fs_eliminar_archivo(SistemaArchivos *fs, const char *nombre)
{
    if (fs == NULL || nombre == NULL) {
        return 0;
    }
    unsigned int idx = fs_hash(nombre);
    Archivo *actual = fs->tabla[idx];
    Archivo *anterior = NULL;

    while (actual != NULL && strcmp(actual->nombre, nombre) != 0) {
        anterior = actual;
        actual = actual->siguiente_hash;
    }
    if (actual == NULL) {
        return 0;
    }

    if (anterior == NULL) {
        fs->tabla[idx] = actual->siguiente_hash;
    } else {
        anterior->siguiente_hash = actual->siguiente_hash;
    }

    /* Liberar la lista de bloques del archivo (recorrido por
     * puntero 'siguiente' hasta NULL). */
    BloqueArchivo *b = actual->primer_bloque;
    while (b != NULL) {
        BloqueArchivo *sig = b->siguiente;
        MT_FREE(b);
        b = sig;
    }
    MT_FREE(actual);
    fs->total_archivos--;
    return 1;
}

void fs_listar_archivos(const SistemaArchivos *fs)
{
    if (fs == NULL || fs->total_archivos == 0) {
        printf("  (no hay archivos registrados)\n");
        return;
    }
    printf("  %-24s %-10s %-8s\n", "NOMBRE", "TAM(bytes)", "BLOQUES");
    for (int i = 0; i < HASH_TAM; i++) {
        for (Archivo *a = fs->tabla[i]; a != NULL; a = a->siguiente_hash) {
            printf("  %-24s %-10d %-8d\n", a->nombre, a->tam_bytes, a->num_bloques);
        }
    }
}

void fs_leer_archivo(SistemaArchivos *fs, const char *nombre)
{
    Archivo *a = fs_buscar_archivo(fs, nombre);
    if (a == NULL) {
        printf("  Error: el archivo '%s' no existe.\n", nombre);
        return;
    }
    printf("  Contenido de '%s' (%d bytes en %d bloque(s)):\n  \"", a->nombre, a->tam_bytes, a->num_bloques);
    int restante = a->tam_bytes;
    for (BloqueArchivo *b = a->primer_bloque; b != NULL; b = b->siguiente) {
        int mostrar = restante < TAM_BLOQUE ? restante : TAM_BLOQUE;
        if (mostrar > 0) {
            fwrite(b->datos, 1, (size_t) mostrar, stdout);
            restante -= mostrar;
        }
    }
    printf("\"\n");
}

void fs_liberar(SistemaArchivos *fs)
{
    if (fs == NULL) {
        return;
    }
    for (int i = 0; i < HASH_TAM; i++) {
        Archivo *a = fs->tabla[i];
        while (a != NULL) {
            Archivo *sig_arch = a->siguiente_hash;
            BloqueArchivo *b = a->primer_bloque;
            while (b != NULL) {
                BloqueArchivo *sig_bloque = b->siguiente;
                MT_FREE(b);
                b = sig_bloque;
            }
            MT_FREE(a);
            a = sig_arch;
        }
        fs->tabla[i] = NULL;
    }
    fs->total_archivos = 0;
}
