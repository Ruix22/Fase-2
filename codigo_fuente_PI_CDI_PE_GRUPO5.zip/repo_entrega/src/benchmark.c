/*
 * benchmark.c - implementacion del benchmark de busqueda
 * lineal vs. busqueda por tabla hash.
 */
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "benchmark.h"
#include "filesystem.h"

#define NUM_BUSQUEDAS 3000

static void preparar_datos(SistemaArchivos *fs, int n)
{
    char nombre[TAM_NOMBRE_ARCH];
    char contenido[16] = "dato";
    for (int i = 0; i < n; i++) {
        snprintf(nombre, sizeof(nombre), "archivo_%06d", i);
        fs_crear_archivo(fs, nombre, contenido);
    }
}

static void medir(SistemaArchivos *fs, int n,
                   double *ms_lineal, double *cmp_lineal,
                   double *ms_hash, double *cmp_hash)
{
    char nombre[TAM_NOMBRE_ARCH];
    long total_cmp_lineal = 0, total_cmp_hash = 0;

    /* --- busqueda lineal (sin usar el indice hash) --- */
    clock_t inicio = clock();
    for (int i = 0; i < NUM_BUSQUEDAS; i++) {
        int idx = rand() % n;
        snprintf(nombre, sizeof(nombre), "archivo_%06d", idx);
        fs_buscar_archivo_lineal(fs, nombre);
        total_cmp_lineal += fs->comparaciones_ultima_busqueda;
    }
    clock_t fin = clock();
    *ms_lineal = 1000.0 * (double)(fin - inicio) / CLOCKS_PER_SEC;
    *cmp_lineal = (double) total_cmp_lineal / NUM_BUSQUEDAS;

    /* --- busqueda optimizada (tabla hash) --- */
    inicio = clock();
    for (int i = 0; i < NUM_BUSQUEDAS; i++) {
        int idx = rand() % n;
        snprintf(nombre, sizeof(nombre), "archivo_%06d", idx);
        fs_buscar_archivo(fs, nombre);
        total_cmp_hash += fs->comparaciones_ultima_busqueda;
    }
    fin = clock();
    *ms_hash = 1000.0 * (double)(fin - inicio) / CLOCKS_PER_SEC;
    *cmp_hash = (double) total_cmp_hash / NUM_BUSQUEDAS;
}

void ejecutar_benchmark(void)
{
    int tamanos[] = {100, 1000, 5000, 10000};
    int num_tamanos = (int)(sizeof(tamanos) / sizeof(tamanos[0]));

    srand(42); /* semilla fija: resultados reproducibles */

    printf("\n=================================================================\n");
    printf(" BENCHMARK: busqueda LINEAL vs. busqueda por TABLA HASH\n");
    printf(" (%d busquedas aleatorias por caso, tiempos en milisegundos)\n", NUM_BUSQUEDAS);
    printf("=================================================================\n");
    printf("  %-8s | %12s %10s | %12s %10s | %10s\n",
           "N", "Lineal(ms)", "Comp.prom", "Hash(ms)", "Comp.prom", "Mejora x");
    printf("  ---------------------------------------------------------------\n");

    for (int i = 0; i < num_tamanos; i++) {
        int n = tamanos[i];
        SistemaArchivos fs;
        fs_inicializar(&fs);
        preparar_datos(&fs, n);

        double ms_lineal, cmp_lineal, ms_hash, cmp_hash;
        medir(&fs, n, &ms_lineal, &cmp_lineal, &ms_hash, &cmp_hash);

        double mejora = (ms_hash > 0.0) ? (ms_lineal / ms_hash) : 0.0;
        printf("  %-8d | %12.3f %10.1f | %12.3f %10.1f | %9.1fx\n",
               n, ms_lineal, cmp_lineal, ms_hash, cmp_hash, mejora);

        fs_liberar(&fs);
    }
    printf("=================================================================\n");
    printf(" Conclusion: la busqueda lineal crece linealmente con N (O(n)),\n");
    printf(" mientras que la busqueda por hash se mantiene practicamente\n");
    printf(" constante (O(1) promedio), como lo confirma la columna de\n");
    printf(" comparaciones promedio por busqueda.\n");
    printf("=================================================================\n");
}
