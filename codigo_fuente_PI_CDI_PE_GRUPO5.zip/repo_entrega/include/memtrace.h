/*
 * memtrace.h
 * ---------------------------------------------------------------
 * Modulo utilitario de trazabilidad de memoria dinamica.
 *
 * Responsabilidad: contabilizar cada reserva (malloc) y liberacion
 * (free) realizada por los modulos del sistema, para poder
 * demostrar -sin depender de herramientas externas como valgrind-
 * que el programa no produce fugas de memoria (memory leaks).
 *
 * Uso: en lugar de llamar a malloc()/free() directamente, los
 * modulos usan MT_MALLOC()/MT_FREE(). Al finalizar el programa se
 * invoca mt_reporte() para verificar que reservas == liberaciones.
 * ---------------------------------------------------------------
 */
#ifndef MEMTRACE_H
#define MEMTRACE_H

#include <stddef.h>

/* Reserva memoria e incrementa el contador global de reservas. */
void *mt_malloc(size_t tam, const char *origen);

/* Libera memoria (si el puntero no es NULL) e incrementa el
 * contador global de liberaciones. */
void mt_free(void *ptr);

/* Imprime un resumen con el total de reservas, liberaciones y
 * bytes actualmente en uso. Retorna 1 si el balance es correcto
 * (no hay fugas) o 0 si detecta una fuga. */
int mt_reporte(void);

#define MT_MALLOC(tam) mt_malloc((tam), __func__)
#define MT_FREE(ptr)   mt_free((ptr))

#endif /* MEMTRACE_H */
