/*
 * kernel.h
 * ---------------------------------------------------------------
 * Modulo de gestion de procesos (contexto: nucleo / kernel).
 *
 * Simula el bloque de control de procesos (PCB) que mantiene un
 * kernel real y un planificador Round Robin sobre una lista
 * enlazada dinamica (implementada como cola circular con punteros
 * frente/final).
 *
 * Responsabilidades del modulo:
 *   - Crear y destruir procesos (memoria dinamica, sin fugas).
 *   - Mantener la cola de procesos listos.
 *   - Planificar la ejecucion mediante el algoritmo Round Robin.
 * ---------------------------------------------------------------
 */
#ifndef KERNEL_H
#define KERNEL_H

#define MAX_NOMBRE_PROCESO 32

typedef enum {
    ESTADO_LISTO,
    ESTADO_EJECUTANDO,
    ESTADO_TERMINADO
} EstadoProceso;

/* Bloque de Control de Proceso (PCB) - nodo de una lista enlazada. */
typedef struct Proceso {
    int pid;
    char nombre[MAX_NOMBRE_PROCESO];
    int prioridad;          /* 1 (alta) - 5 (baja), solo informativo */
    int rafaga_total;       /* tiempo de CPU requerido, en unidades */
    int rafaga_restante;    /* tiempo de CPU que aun falta ejecutar */
    EstadoProceso estado;
    struct Proceso *siguiente;
} Proceso;

/* Cola de procesos (estructura de datos que administra la lista). */
typedef struct {
    Proceso *frente;
    Proceso *final;
    int cantidad;
    int siguiente_pid;
} ColaProcesos;

/* Inicializa una cola vacia. Debe llamarse antes de usar la cola. */
void cola_inicializar(ColaProcesos *cola);

/* Crea un proceso nuevo (reserva memoria dinamica) y lo encola.
 * Retorna un puntero al proceso creado, o NULL si fallo la reserva
 * o si los parametros de entrada no son validos. */
Proceso *proceso_crear(ColaProcesos *cola, const char *nombre,
                        int prioridad, int rafaga);

/* Busca y elimina de la cola el proceso con el pid indicado,
 * liberando su memoria. Retorna 1 si lo encontro y elimino, 0 si
 * no existe un proceso con ese pid. */
int proceso_eliminar(ColaProcesos *cola, int pid);

/* Imprime en pantalla el estado actual de todos los procesos. */
void cola_listar(const ColaProcesos *cola);

/* Ejecuta el algoritmo de planificacion Round Robin con el
 * quantum indicado (unidades de tiempo por turno) sobre los
 * procesos en estado LISTO/EJECUTANDO. Los procesos que terminan
 * pasan a ESTADO_TERMINADO y se eliminan de la cola activa. */
void planificador_round_robin(ColaProcesos *cola, int quantum);

/* Libera toda la memoria dinamica asociada a la cola (todos los
 * nodos Proceso restantes). Debe invocarse antes de finalizar el
 * programa para evitar fugas de memoria. */
void cola_liberar(ColaProcesos *cola);

#endif /* KERNEL_H */
