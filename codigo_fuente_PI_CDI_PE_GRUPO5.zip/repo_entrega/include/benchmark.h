/*
 * benchmark.h
 * ---------------------------------------------------------------
 * Modulo de medicion de rendimiento.
 *
 * Compara la busqueda de archivos por metodo LINEAL (recorrido de
 * toda la estructura, O(n)) contra la busqueda por TABLA HASH
 * (O(1) promedio), para distintos tamanos de N. Esta comparacion
 * es la evidencia de la optimizacion aplicada al modulo de
 * sistema de archivos (ver informe, seccion 4).
 * ---------------------------------------------------------------
 */
#ifndef BENCHMARK_H
#define BENCHMARK_H

/* Ejecuta el benchmark para los tamanos de N definidos internamente
 * (100, 1000, 5000, 10000 archivos) e imprime una tabla comparativa
 * con tiempo (ms) y numero promedio de comparaciones para cada
 * metodo de busqueda. */
void ejecutar_benchmark(void);

#endif /* BENCHMARK_H */
