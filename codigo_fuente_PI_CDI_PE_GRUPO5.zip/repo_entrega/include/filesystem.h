/*
 * filesystem.h
 * ---------------------------------------------------------------
 * Modulo de gestion de bloques de archivo (contexto: sistemas de
 * archivos).
 *
 * Simula la asignacion enlazada de bloques (similar en concepto a
 * la asignacion enlazada de FAT/ext), donde el contenido de cada
 * archivo se reparte en bloques de tamano fijo reservados
 * dinamicamente y conectados mediante punteros.
 *
 * Ademas de la lista de archivos, se mantiene una TABLA HASH para
 * la busqueda de archivos por nombre. Esta es la mejora de
 * eficiencia (ver seccion de optimizacion del informe): pasar de
 * una busqueda lineal O(n) a una busqueda por hash con complejidad
 * promedio O(1).
 * ---------------------------------------------------------------
 */
#ifndef FILESYSTEM_H
#define FILESYSTEM_H

#include <stddef.h>

#define TAM_BLOQUE      64   /* bytes utiles de datos por bloque   */
#define TAM_NOMBRE_ARCH  64
#define HASH_TAM        64   /* numero de listas (cubetas) del hash */

/* Bloque de datos de un archivo - nodo de una lista enlazada. */
typedef struct BloqueArchivo {
    int id_bloque;
    char datos[TAM_BLOQUE];
    struct BloqueArchivo *siguiente;
} BloqueArchivo;

/* Metadatos de un archivo. primer_bloque encabeza la lista de
 * bloques que contienen su informacion. siguiente_hash encadena
 * los archivos que colisionan en la misma cubeta de la tabla hash. */
typedef struct Archivo {
    char nombre[TAM_NOMBRE_ARCH];
    int tam_bytes;
    int num_bloques;
    BloqueArchivo *primer_bloque;
    struct Archivo *siguiente_hash;
} Archivo;

/* Sistema de archivos simulado: tabla hash de archivos. */
typedef struct {
    Archivo *tabla[HASH_TAM];
    int total_archivos;
    int total_bloques_reservados;
    long comparaciones_ultima_busqueda; /* metrica para el benchmark */
} SistemaArchivos;

void fs_inicializar(SistemaArchivos *fs);

/* Calcula el indice hash (0..HASH_TAM-1) para un nombre de archivo. */
unsigned int fs_hash(const char *nombre);

/* Crea un archivo con el contenido dado: reserva dinamicamente los
 * bloques necesarios (redondeando hacia arriba) y los enlaza por
 * puntero. Retorna el archivo creado o NULL si el nombre ya existe
 * o si fallo la reserva de memoria. */
Archivo *fs_crear_archivo(SistemaArchivos *fs, const char *nombre,
                           const char *contenido);

/* Busca un archivo por nombre usando la tabla hash: O(1) promedio.
 * Actualiza fs->comparaciones_ultima_busqueda con el numero de
 * comparaciones de cadenas realizadas (para medir eficiencia). */
Archivo *fs_buscar_archivo(SistemaArchivos *fs, const char *nombre);

/* Version de referencia (NO optimizada) que recorre todos los
 * archivos de forma lineal, ignorando la tabla hash. Se usa solo
 * para el benchmark comparativo de rendimiento (seccion 4). */
Archivo *fs_buscar_archivo_lineal(SistemaArchivos *fs, const char *nombre);

/* Elimina un archivo y libera todos sus bloques y su nodo. Retorna
 * 1 si lo elimino, 0 si no existia. */
int fs_eliminar_archivo(SistemaArchivos *fs, const char *nombre);

/* Imprime el listado de archivos con su tamano y numero de bloques. */
void fs_listar_archivos(const SistemaArchivos *fs);

/* Recorre e imprime el contenido de un archivo, bloque por bloque. */
void fs_leer_archivo(SistemaArchivos *fs, const char *nombre);

/* Libera toda la memoria dinamica del sistema de archivos (todos
 * los bloques y todos los nodos Archivo). */
void fs_liberar(SistemaArchivos *fs);

#endif /* FILESYSTEM_H */
